import tkinter as tk
from tkinter import messagebox

def calculate():
    try:
        num1 = float(entry_num1.get())
        num2 = float(entry_num2.get())
        operation = selected_operation.get()

        if operation == "Add":
            result = num1 + num2
        elif operation == "Subtract":
            result = num1 - num2
        elif operation == "Multiply":
            result = num1 * num2
        elif operation == "Divide":
            if num2 == 0:
                messagebox.showerror("Error", "Cannot divide by zero!")
                return
            result = num1 / num2
        else:
            messagebox.showerror("Error", "Please select an operation!")
            return

        result_label.config(text=f"Result: {result}")

    except ValueError:
        messagebox.showerror("Error", "Invalid input! Please enter numbers only.")

# Create the main window
root = tk.Tk()
root.title("Calculator")
root.configure(bg="#D8BFD8")  # Background color for the window


tk.Label(root, text="Enter first number:", bg="#f0f8ff", fg="#000080", font=("Arial", 12)).grid(row=0, column=0, padx=10, pady=5)
entry_num1 = tk.Entry(root, bg="#ffffff", fg="#000000", font=("Arial", 12))
entry_num1.grid(row=0, column=1, padx=10, pady=5)

tk.Label(root, text="Enter second number:", bg="#f0f8ff", fg="#000080", font=("Arial", 12)).grid(row=1, column=0, padx=10, pady=5)
entry_num2 = tk.Entry(root, bg="#ffffff", fg="#000000", font=("Arial", 12))
entry_num2.grid(row=1, column=1, padx=10, pady=5)


selected_operation = tk.StringVar(value="Add")

tk.Radiobutton(root, text="Add", variable=selected_operation, value="Add", bg="#f0f8ff", fg="#000000", font=("Arial", 12)).grid(row=2, column=0, padx=10, pady=5)
tk.Radiobutton(root, text="Subtract", variable=selected_operation, value="Subtract", bg="#f0f8ff", fg="#000000", font=("Arial", 12)).grid(row=2, column=1, padx=10, pady=5)
tk.Radiobutton(root, text="Multiply", variable=selected_operation, value="Multiply", bg="#f0f8ff", fg="#000000", font=("Arial", 12)).grid(row=3, column=0, padx=10, pady=5)
tk.Radiobutton(root, text="Divide", variable=selected_operation, value="Divide", bg="#f0f8ff", fg="#000000", font=("Arial", 12)).grid(row=3, column=1, padx=10, pady=5)

calculate_button = tk.Button(root, text="Calculate", command=calculate, bg="#4682b4", fg="#ffffff", font=("Arial", 12, "bold"))
calculate_button.grid(row=4, column=0, columnspan=2, padx=10, pady=10)

result_label = tk.Label(root, text="Result:", bg="#f0f8ff", fg="#000080", font=("Arial", 12, "bold"))
result_label.grid(row=5, column=0, columnspan=2, padx=10, pady=5)

# Start the main event loop
root.mainloop()
