import random
import string
print("=====Welcome to Password Generator=====")
def choice():
    cho=input("\npress 1 for numeric\npress 2 for Aplabet \npress 3 for Alpha-numeric\nEnter which Type of Password You Want :")
    if cho =="1":
        lent=int(input("Enter the length \n press 1 for 4 digit \n press 2 for 5 digit\n press 3 for 6 digit \n press 4 for 7 digit\n press 5 for 8 digit :\n"))
        if lent==1:
            print("Your password is :",random.randint(1000,9999))
        elif lent==2:
            print("Your password is :",random.randint(10000,99999))
        elif lent==3:
            print("Your password is :",random.randint(100000,999999))
        elif lent==4:
            print("Your password is :",random.randint(1000000,99999999))
        elif lent==5:
            print("Your password is :",random.randint(10000000,99999999))
        else:
            print("Inavlid Choice!!")
    if cho=="2":
        len2=int(input("Enter the length :\n"))
        i=''.join(random.choice(string.ascii_letters)for _ in range(len2))
        print("Generated Password:",i)    
    if cho=="3":
        length=int(input("Enter the length"))
        characters = string.ascii_letters + string.digits 
        password = ''.join(random.choice(characters) for _ in range(length))
        print( "Generated Password:",password)
    print("******THANKYOU******")
if __name__ == "__main__":
    choice()
